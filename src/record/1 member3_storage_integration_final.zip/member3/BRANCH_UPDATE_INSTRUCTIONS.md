# Member 3 Branch Update Instructions

Copy these files into the repository root of your `member3-storage-integration` branch:

- `docs/member3_storage_integration_plan.md`
- `src/data/storage.py`
- `tests/test_storage.py`
- `tests/test_integration.py`

Recommended commit order:
1. `docs: Add member 3 storage integration plan.`
2. `storage: Standardise record path resolution.`
3. `storage: Handle missing and malformed record files safely.`
4. `tests: Add unit tests for storage layer.`
5. `tests: Add integration tests for persistence workflow.`

After copying the files, run:

```bash
pip install -r requirements.txt
pytest -q
python src/main.py
```

Expected result:
- all tests pass
- the GUI starts normally
- records persist between runs
